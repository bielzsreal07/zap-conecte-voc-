
export enum AppView {
  AUTH = 'auth',
  ONBOARDING = 'onboarding',
  VERIFY = 'verify',
  DASHBOARD = 'dashboard',
  CHAT = 'chat',
  BUSINESS = 'business',
  CONTACTS = 'contacts',
  ADMIN = 'admin',
  PROFILE = 'profile'
}

export type MessageStatus = 'sent' | 'delivered' | 'read';
export type MessageType = 'text' | 'image' | 'audio' | 'doc';

export interface User {
  id: string;
  name: string;
  phone?: string;
  email: string;
  password?: string; // Salvar senha para persistência
  verified?: boolean; // Controle se já confirmou o código
  avatar?: string;
  isOnline: boolean;
  isBusiness: boolean;
  status?: string;
  bio?: string;
  tags?: string[];
}

export interface ChatMessage {
  id: string;
  chatId: string;
  senderId: string;
  content: string;
  type: MessageType;
  status: MessageStatus;
  timestamp: number;
}

export interface Conversation {
  id: string;
  participants: User[];
  messages: ChatMessage[];
  unreadCount: number;
}

export interface GeneratedAsset {
  id: string;
  type: 'image' | 'video';
  url: string;
  prompt: string;
  timestamp: number;
}

export interface Campaign {
  id: string;
  name: string;
  template: string;
  status: 'completed' | 'sending' | 'failed' | 'scheduled';
  sentCount: number;
  readCount: number;
  totalTarget: number;
  timestamp: number;
}
