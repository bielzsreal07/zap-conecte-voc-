
import React, { useState } from 'react';
import { DatabaseService } from '../services/database';
import { Icons } from '../constants';

const BusinessView: React.FC = () => {
  const [message, setMessage] = useState('');
  const [isSending, setIsSending] = useState(false);
  const [progress, setProgress] = useState({ current: 0, total: 0 });
  const [status, setStatus] = useState<string | null>(null);

  const handleBulkSend = async () => {
    const session = DatabaseService.getSession();
    if (!session || !message.trim()) return;

    const totalUsers = DatabaseService.getAllUsers().length - 1;
    if (totalUsers <= 0) {
      setStatus("Você não tem clientes cadastrados para enviar.");
      return;
    }

    setIsSending(true);
    setStatus(null);
    
    await DatabaseService.sendBulkMessage(session.id, message, (current, total) => {
      setProgress({ current, total });
    });

    setIsSending(false);
    setMessage('');
    setStatus(`Sucesso! Mensagem enviada para ${totalUsers} contatos.`);
    setTimeout(() => setStatus(null), 5000);
  };

  return (
    <div className="p-8 max-w-4xl mx-auto space-y-10 animate-in fade-in duration-500">
      <header className="text-center space-y-4">
        <h2 className="text-4xl font-black">Lista de <span className="text-purple-400">Transmissão</span></h2>
        <p className="text-slate-500 font-medium">Envie mensagens em massa para todos os seus clientes salvos no Zap Conect</p>
      </header>

      <div className="glass-panel p-10 rounded-[3rem] border-white/10 shadow-2xl space-y-8">
        <div className="space-y-4">
          <div className="flex justify-between items-center px-1">
            <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Sua Mensagem de Transmissão</label>
            <span className="text-[10px] font-bold text-purple-400 bg-purple-500/10 px-2 py-1 rounded">Envio Automático</span>
          </div>
          <textarea 
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            disabled={isSending}
            placeholder="Olá! Estamos com uma nova promoção... (Esta mensagem chegará para TODOS os seus contatos salvos)"
            className="w-full bg-slate-900 border border-slate-800 rounded-[2rem] p-8 text-slate-200 outline-none focus:ring-4 focus:ring-purple-500/20 min-h-[250px] transition-all resize-none leading-relaxed"
          />
        </div>

        {isSending && (
          <div className="space-y-3 animate-in fade-in zoom-in">
            <div className="flex justify-between text-[10px] font-black uppercase tracking-widest text-slate-500">
              <span>Progresso do Disparo</span>
              <span className="text-purple-400">{progress.current} / {progress.total} Clientes</span>
            </div>
            <div className="w-full h-3 bg-slate-800 rounded-full overflow-hidden">
              <div 
                className="h-full bg-gradient-to-r from-purple-600 to-purple-400 transition-all duration-300" 
                style={{ width: `${(progress.current / progress.total) * 100}%` }}
              />
            </div>
          </div>
        )}

        {status && (
          <div className={`p-4 rounded-2xl text-center text-xs font-bold uppercase tracking-widest ${status.includes('Sucesso') ? 'bg-emerald-500/10 text-emerald-400' : 'bg-red-500/10 text-red-400'}`}>
            {status}
          </div>
        )}

        <button 
          onClick={handleBulkSend}
          disabled={isSending || !message.trim()}
          className="w-full py-5 bg-purple-600 text-white font-black rounded-[2rem] hover:bg-purple-500 transition-all shadow-xl shadow-purple-600/20 active:scale-95 disabled:opacity-30 disabled:grayscale flex items-center justify-center gap-3 text-lg"
        >
          {isSending ? (
            <>
              <div className="w-6 h-6 border-4 border-white border-t-transparent rounded-full animate-spin"></div>
              ENVIANDO MENSAGENS...
            </>
          ) : (
            <>
              <Icons.Send />
              DISPARAR PARA TODOS OS CLIENTES
            </>
          )}
        </button>

        <div className="flex items-center gap-4 p-6 bg-slate-900/40 rounded-3xl border border-white/5">
           <div className="w-12 h-12 rounded-full bg-purple-500/10 flex items-center justify-center text-purple-400">
              <svg xmlns="http://www.w3.org/2000/svg" className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
           </div>
           <p className="text-[10px] text-slate-500 font-medium leading-relaxed">
             <span className="font-black text-slate-300 block mb-1">Dica de Segurança:</span>
             Evite enviar mensagens repetitivas em intervalos muito curtos para garantir a melhor taxa de entrega e evitar bloqueios.
           </p>
        </div>
      </div>
    </div>
  );
};

export default BusinessView;
