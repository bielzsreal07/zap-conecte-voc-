
import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality } from '@google/genai';
import { Icons } from '../constants';
import { encodePCM, decodeAudioData, decodeBase64 } from '../services/geminiService';

const VoiceView: React.FC = () => {
  const [isActive, setIsActive] = useState(false);
  const [transcripts, setTranscripts] = useState<string[]>([]);
  const [isMuted, setIsMuted] = useState(false);
  
  const audioContextRef = useRef<{ input: AudioContext; output: AudioContext } | null>(null);
  const sessionRef = useRef<any>(null);
  const nextStartTimeRef = useRef(0);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());

  const startSession = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      
      const inputCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      const outputCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      audioContextRef.current = { input: inputCtx, output: outputCtx };

      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
      
      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-12-2025',
        callbacks: {
          onopen: () => {
            console.log('Sessão Zap Conect aberta');
            const source = inputCtx.createMediaStreamSource(stream);
            const scriptProcessor = inputCtx.createScriptProcessor(4096, 1, 1);
            
            scriptProcessor.onaudioprocess = (e) => {
              if (isMuted) return;
              const inputData = e.inputBuffer.getChannelData(0);
              const int16 = new Int16Array(inputData.length);
              for (let i = 0; i < inputData.length; i++) {
                int16[i] = inputData[i] * 32768;
              }
              const pcmBlob = {
                data: encodePCM(new Uint8Array(int16.buffer)),
                mimeType: 'audio/pcm;rate=16000',
              };
              
              sessionPromise.then(session => {
                session.sendRealtimeInput({ media: pcmBlob });
              });
            };
            
            source.connect(scriptProcessor);
            scriptProcessor.connect(inputCtx.destination);
          },
          onmessage: async (message: LiveServerMessage) => {
            const audioData = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
            if (audioData) {
              const { output: ctx } = audioContextRef.current!;
              nextStartTimeRef.current = Math.max(nextStartTimeRef.current, ctx.currentTime);
              
              const buffer = await decodeAudioData(decodeBase64(audioData), ctx, 24000, 1);
              const source = ctx.createBufferSource();
              source.buffer = buffer;
              source.connect(ctx.destination);
              source.start(nextStartTimeRef.current);
              nextStartTimeRef.current += buffer.duration;
              sourcesRef.current.add(source);
              source.onended = () => sourcesRef.current.delete(source);
            }

            if (message.serverContent?.interrupted) {
              sourcesRef.current.forEach(s => s.stop());
              sourcesRef.current.clear();
              nextStartTimeRef.current = 0;
            }

            if (message.serverContent?.outputTranscription) {
               setTranscripts(prev => [...prev.slice(-4), message.serverContent?.outputTranscription?.text || '']);
            }
          },
          onerror: (e) => console.error('Erro de Conexão:', e),
          onclose: () => setIsActive(false),
        },
        config: {
          responseModalities: [Modality.AUDIO],
          outputAudioTranscription: {},
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } }
          },
          systemInstruction: "Você é o assistente vocal do Zap Conect. Responda de forma curta e natural, como em uma ligação telefônica."
        }
      });

      sessionRef.current = await sessionPromise;
      setIsActive(true);
    } catch (err) {
      console.error('Falha ao iniciar sessão vocal:', err);
    }
  };

  const stopSession = () => {
    if (sessionRef.current) {
      sessionRef.current.close();
      sessionRef.current = null;
    }
    if (audioContextRef.current) {
      audioContextRef.current.input.close();
      audioContextRef.current.output.close();
      audioContextRef.current = null;
    }
    setIsActive(false);
  };

  return (
    <div className="flex flex-col items-center justify-center h-[calc(100vh-180px)] space-y-12">
      <div className="relative">
        <div className={`absolute inset-0 rounded-full border-2 border-teal-500/20 transition-all duration-1000 ${isActive ? 'scale-[2] opacity-0 animate-ping' : 'scale-100 opacity-0'}`}></div>
        <div className={`absolute inset-0 rounded-full border-2 border-blue-500/20 transition-all duration-1000 [animation-delay:0.5s] ${isActive ? 'scale-[2.5] opacity-0 animate-ping' : 'scale-100 opacity-0'}`}></div>
        
        <div className={`w-48 h-48 rounded-full flex items-center justify-center transition-all duration-500 relative z-10 ${
          isActive ? 'bg-teal-600 shadow-[0_0_60px_rgba(20,184,166,0.4)]' : 'bg-slate-800'
        }`}>
          <div className="text-white">
            {isActive ? <div className="flex gap-1">
              {[1, 2, 3, 4, 5].map(i => (
                <div key={i} className={`w-1.5 h-8 bg-white rounded-full animate-[voice-pulse_1s_ease-in-out_infinite]`} style={{ animationDelay: `${i * 0.1}s` }}></div>
              ))}
            </div> : <Icons.Voice />}
          </div>
        </div>
      </div>

      <div className="text-center space-y-4 max-w-lg">
        <h2 className="text-2xl font-bold text-slate-100">{isActive ? 'Zap Conect está ouvindo...' : 'Falar com o Zap Conect'}</h2>
        <p className="text-slate-400">Interação de voz em tempo real. Converse naturalmente e receba respostas instantâneas.</p>
        
        <div className="flex justify-center gap-4 mt-8">
          {isActive ? (
            <>
              <button 
                onClick={() => setIsMuted(!isMuted)}
                className={`p-4 rounded-full transition-all ${isMuted ? 'bg-red-500/20 text-red-400' : 'bg-slate-800 text-slate-400'}`}
              >
                {isMuted ? 'Ativar Áudio' : 'Mutar Microfone'}
              </button>
              <button 
                onClick={stopSession}
                className="px-8 py-4 bg-red-600 text-white rounded-full font-bold hover:bg-red-500 transition-all"
              >
                Encerrar Chamada
              </button>
            </>
          ) : (
            <button 
              onClick={startSession}
              className="px-12 py-4 bg-gradient-to-r from-teal-600 to-blue-600 text-white rounded-full font-bold text-lg hover:shadow-xl hover:shadow-teal-500/30 transition-all flex items-center gap-3"
            >
              <Icons.Voice /> Iniciar Conexão
            </button>
          )}
        </div>
      </div>

      {isActive && transcripts.length > 0 && (
        <div className="w-full max-w-2xl bg-slate-900/50 border border-slate-800 rounded-2xl p-6">
           <p className="text-xs font-medium text-slate-500 mb-3 uppercase tracking-wider">Transcrição ao Vivo</p>
           <div className="space-y-2">
             {transcripts.map((t, i) => (
               <p key={i} className="text-slate-300 text-sm animate-in fade-in slide-in-from-left-2">{t}</p>
             ))}
           </div>
        </div>
      )}
    </div>
  );
};

export default VoiceView;
