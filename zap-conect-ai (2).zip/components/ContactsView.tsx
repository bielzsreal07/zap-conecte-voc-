
import React, { useState, useEffect } from 'react';
import { User } from '../types';
import { Icons } from '../constants';
import { DatabaseService } from '../services/database';

interface ContactsProps {
  onSelectChat: () => void;
}

const ContactsView: React.FC<ContactsProps> = ({ onSelectChat }) => {
  const [contacts, setContacts] = useState<User[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isAdding, setIsAdding] = useState(false);
  const [newContact, setNewContact] = useState({ name: '', phone: '' });

  useEffect(() => {
    loadContacts();
  }, []);

  const loadContacts = () => {
    // Filtra para mostrar apenas contatos que não são o usuário logado e que possuem telefone
    const all = DatabaseService.getAllUsers();
    setContacts(all);
  };

  const handleAddContact = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newContact.name || !newContact.phone) return;

    const contactUser: User = {
      id: 'c-' + Math.random().toString(36).substr(2, 9),
      name: newContact.name,
      email: `${newContact.phone}@contato.local`, // E-mail interno fictício
      phone: newContact.phone,
      isOnline: false,
      isBusiness: false,
      avatar: "",
      verified: true // Contatos manuais já são considerados "verificados"
    };

    DatabaseService.saveUser(contactUser);
    setNewContact({ name: '', phone: '' });
    setIsAdding(false);
    loadContacts();
  };

  const filteredContacts = contacts.filter(c => 
    c.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    (c.phone && c.phone.includes(searchTerm))
  );

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-10 animate-in fade-in duration-500">
      <header className="flex justify-between items-center">
        <div>
          <h2 className="text-4xl font-black">Minha <span className="text-[#00a884]">Agenda</span></h2>
          <p className="text-[#8696a0] font-medium">Gerencie seus clientes apenas por nome e telefone</p>
        </div>
        <button 
          onClick={() => setIsAdding(true)}
          className="bg-[#00a884] text-[#111b21] px-6 py-3 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-[#06cf9c] transition-all flex items-center gap-2 shadow-lg shadow-[#00a884]/20 active:scale-95"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M12 4v16m8-8H4" /></svg>
          Adicionar Cliente
        </button>
      </header>

      {isAdding && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-6 bg-[#0b141acc] backdrop-blur-sm">
          <form onSubmit={handleAddContact} className="bg-[#222e35] w-full max-w-md p-10 rounded-[2.5rem] border border-white/5 animate-in zoom-in-95 shadow-2xl">
            <h3 className="text-xl font-black mb-8 text-[#e9edef]">Novo Contato</h3>
            <div className="space-y-6">
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-[#00a884] uppercase tracking-widest ml-1">Nome do Cliente</label>
                <input 
                  required
                  placeholder="Ex: João Silva"
                  className="w-full bg-[#2a3942] border-none rounded-xl px-5 py-4 text-sm text-[#e9edef] outline-none focus:ring-2 focus:ring-[#00a884]/30"
                  value={newContact.name}
                  onChange={e => setNewContact({...newContact, name: e.target.value})}
                />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-[#00a884] uppercase tracking-widest ml-1">Telefone / WhatsApp</label>
                <input 
                  required
                  placeholder="+55 (00) 00000-0000"
                  className="w-full bg-[#2a3942] border-none rounded-xl px-5 py-4 text-sm text-[#e9edef] outline-none focus:ring-2 focus:ring-[#00a884]/30"
                  value={newContact.phone}
                  onChange={e => setNewContact({...newContact, phone: e.target.value})}
                />
              </div>
            </div>
            <div className="flex gap-4 mt-10">
              <button type="button" onClick={() => setIsAdding(false)} className="flex-1 py-4 text-[#8696a0] font-bold hover:text-[#e9edef] transition-all uppercase text-xs tracking-widest">Cancelar</button>
              <button type="submit" className="flex-1 py-4 bg-[#00a884] text-[#111b21] font-black rounded-xl hover:bg-[#06cf9c] transition-all uppercase text-xs tracking-widest shadow-lg shadow-[#00a884]/10">SALVAR</button>
            </div>
          </form>
        </div>
      )}

      <div className="bg-[#222e35] p-2 rounded-2xl border border-white/5 flex gap-4">
        <div className="relative flex-1">
          <input 
            type="text" 
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Pesquisar por nome ou número..." 
            className="w-full bg-[#111b21] border-none rounded-xl py-4 pl-12 pr-4 text-sm outline-none focus:ring-2 focus:ring-[#00a884]/20 transition-all text-[#e9edef] placeholder-[#8696a0]"
          />
          <div className="absolute left-4 top-4 text-[#8696a0]"><Icons.Chat /></div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {filteredContacts.map((contact) => (
          <div key={contact.id} className="bg-[#222e35] p-6 rounded-[2rem] border border-white/5 hover:border-[#00a884]/20 transition-all group relative overflow-hidden shadow-lg">
            <div className="flex flex-col items-center text-center">
              <div className="w-20 h-20 rounded-2xl bg-[#111b21] border border-white/5 flex items-center justify-center mb-4 text-[#8696a0] group-hover:scale-105 transition-all p-4">
                {contact.avatar ? <img src={contact.avatar} className="w-full h-full object-cover rounded-2xl" /> : <Icons.User />}
              </div>
              <h4 className="font-bold text-[#e9edef] text-base truncate w-full">{contact.name}</h4>
              <p className="text-[11px] text-[#00a884] mb-6 font-bold tracking-tight w-full">{contact.phone || 'Sem número'}</p>
              <button 
                onClick={onSelectChat}
                className="w-full py-3 bg-[#2a3942] text-[#d1d7db] rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-[#00a884] hover:text-[#111b21] transition-all active:scale-95"
              >
                Abrir Conversa
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ContactsView;
