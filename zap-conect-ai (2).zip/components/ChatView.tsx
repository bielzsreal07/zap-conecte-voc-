
import React, { useState, useRef, useEffect } from 'react';
import { User, ChatMessage, Conversation, AppView } from '../types';
import { Icons } from '../constants';
import { DatabaseService } from '../services/database';

interface ChatProps {
  currentUser: User;
  onNavigate?: (view: AppView) => void;
  onLogout?: () => void;
}

const ChatView: React.FC<ChatProps> = ({ currentUser, onNavigate, onLogout }) => {
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [selectedChat, setSelectedChat] = useState<Conversation | null>(null);
  const [messageText, setMessageText] = useState('');
  const [isOtherTyping, setIsOtherTyping] = useState(false);
  const [showAddContact, setShowAddContact] = useState(false);
  const [showMenu, setShowMenu] = useState(false);
  const [newContact, setNewContact] = useState({ name: '', phone: '' });
  
  const scrollRef = useRef<HTMLDivElement>(null);
  const typingTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const menuRef = useRef<HTMLDivElement>(null);

  const loadData = () => {
    const allUsers = DatabaseService.getAllUsers().filter((u: User) => u.id !== currentUser.id);
    
    const updatedConversations: Conversation[] = allUsers.map((u: User) => {
      const chatId = [currentUser.id, u.id].sort().join('_');
      DatabaseService.markMessagesAsDelivered(chatId, currentUser.id);

      return {
        id: chatId,
        participants: [u],
        messages: DatabaseService.getMessagesForChat(chatId),
        unreadCount: 0
      };
    });

    setConversations(updatedConversations);
    
    if (selectedChat) {
      const currentSelected = updatedConversations.find(c => c.id === selectedChat.id);
      if (currentSelected) {
        setSelectedChat(currentSelected);
        const otherParticipant = currentSelected.participants[0];
        setIsOtherTyping(DatabaseService.isUserTyping(currentSelected.id, otherParticipant.id));
      }
    }
  };

  useEffect(() => {
    loadData();
    const interval = setInterval(loadData, 2000);
    return () => clearInterval(interval);
  }, [currentUser.id, selectedChat?.id]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setShowMenu(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [selectedChat?.messages, isOtherTyping]);

  const handleAddContact = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newContact.name || !newContact.phone) return;

    const contactUser: User = {
      id: 'c-' + Math.random().toString(36).substr(2, 9),
      name: newContact.name,
      email: `${newContact.phone.replace(/\D/g, '')}@contato.local`,
      phone: newContact.phone,
      isOnline: false,
      isBusiness: false,
      avatar: "",
      verified: true
    };

    DatabaseService.saveUser(contactUser);
    setNewContact({ name: '', phone: '' });
    setShowAddContact(false);
    loadData();
  };

  const handleSendMessage = () => {
    if (!messageText.trim() || !selectedChat) return;

    const newMessage: ChatMessage = {
      id: Date.now().toString(),
      chatId: selectedChat.id,
      senderId: currentUser.id,
      content: messageText,
      type: 'text',
      status: 'sent',
      timestamp: Date.now()
    };

    DatabaseService.setTypingStatus(selectedChat.id, currentUser.id, false);
    DatabaseService.saveMessage(newMessage);
    loadData();
    setMessageText('');
  };

  const renderCheckmarks = (status: 'sent' | 'delivered' | 'read') => {
    switch (status) {
      case 'read': return <span className="text-[#53bdeb] font-bold text-[13px]">✓✓</span>;
      case 'delivered': return <span className="text-[#8696a0] font-bold text-[13px]">✓✓</span>;
      default: return <span className="text-[#8696a0] font-bold text-[13px]">✓</span>;
    }
  };

  return (
    <div className="flex h-full bg-[#0b141a] relative">
      {/* Modal Adicionar Contato (Ativado pelo botão +) */}
      {showAddContact && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/70 backdrop-blur-md p-4">
          <form onSubmit={handleAddContact} className="bg-[#222e35] w-full max-w-sm p-8 rounded-3xl shadow-2xl border border-white/5 animate-in zoom-in-95">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-xl font-bold text-[#e9edef]">Adicionar Cliente</h3>
              <button type="button" onClick={() => setShowAddContact(false)} className="text-[#8696a0] hover:text-white">✕</button>
            </div>
            <div className="space-y-4">
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-[#00a884] uppercase tracking-widest ml-1">Nome Completo</label>
                <input 
                  required
                  placeholder="Ex: Maria Oliveira"
                  className="w-full bg-[#2a3942] border-none rounded-xl px-4 py-3.5 text-sm text-[#e9edef] outline-none focus:ring-2 focus:ring-[#00a884]/50 transition-all"
                  value={newContact.name}
                  onChange={e => setNewContact({...newContact, name: e.target.value})}
                />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-[#00a884] uppercase tracking-widest ml-1">Número do WhatsApp</label>
                <input 
                  required
                  placeholder="+55 (11) 99999-9999"
                  className="w-full bg-[#2a3942] border-none rounded-xl px-4 py-3.5 text-sm text-[#e9edef] outline-none focus:ring-2 focus:ring-[#00a884]/50 transition-all"
                  value={newContact.phone}
                  onChange={e => setNewContact({...newContact, phone: e.target.value})}
                />
              </div>
            </div>
            <div className="flex gap-3 mt-8">
              <button type="button" onClick={() => setShowAddContact(false)} className="flex-1 py-3 text-[#8696a0] text-sm font-bold hover:text-white transition-all uppercase tracking-wider">Cancelar</button>
              <button type="submit" className="flex-1 py-3 bg-[#00a884] text-[#111b21] font-bold rounded-xl hover:bg-[#06cf9c] transition-all shadow-lg shadow-[#00a884]/20 uppercase tracking-wider">Salvar</button>
            </div>
          </form>
        </div>
      )}

      {/* Lista de Conversas (Esquerda) */}
      <div className="w-[400px] border-r border-[#2a3942] flex flex-col bg-[#111b21] shrink-0">
        <header className="h-[59px] bg-[#202c33] flex items-center justify-between px-4 py-2 shrink-0">
          <div className="flex items-center gap-4">
             <div className="w-10 h-10 rounded-full bg-[#00a884] flex items-center justify-center p-2 text-[#111b21] shadow-inner">
                <Icons.Rocket />
             </div>
             <h2 className="text-[#e9edef] font-bold text-[16px]">Conversas</h2>
          </div>
          <div className="flex gap-4 text-[#aebac1] relative">
             {/* BOTÃO + (ADICIONAR) - AGORA FUNCIONAL */}
             <button 
                onClick={() => setShowAddContact(true)}
                className="p-2 hover:bg-white/10 rounded-full transition-all active:scale-90"
                title="Novo Contato"
             >
                <svg xmlns="http://www.w3.org/2000/svg" className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M12 4v16m8-8H4" /></svg>
             </button>

             {/* BOTÃO ⋮ (MENU) - AGORA FUNCIONAL */}
             <button 
                onClick={() => setShowMenu(!showMenu)}
                className={`p-2 rounded-full transition-all active:scale-90 ${showMenu ? 'bg-white/10 text-white' : 'hover:bg-white/10'}`}
                title="Mais opções"
             >
                <svg xmlns="http://www.w3.org/2000/svg" className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24"><path d="M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z"/></svg>
             </button>

             {/* Dropdown Menu de Opções */}
             {showMenu && (
               <div ref={menuRef} className="absolute top-11 right-0 w-52 bg-[#233138] rounded-lg shadow-2xl py-2 z-[60] border border-white/5 animate-in fade-in slide-in-from-top-2 origin-top-right">
                 <button 
                    onClick={() => { onNavigate?.(AppView.PROFILE); setShowMenu(false); }}
                    className="w-full px-6 py-3.5 text-left text-[#d1d7db] text-sm hover:bg-[#111b21] transition-colors flex items-center gap-3"
                 >
                   <Icons.User /> Perfil
                 </button>
                 <button 
                    onClick={() => { onNavigate?.(AppView.PROFILE); setShowMenu(false); }}
                    className="w-full px-6 py-3.5 text-left text-[#d1d7db] text-sm hover:bg-[#111b21] transition-colors flex items-center gap-3"
                 >
                   <Icons.Settings /> Configurações
                 </button>
                 <div className="h-[1px] bg-white/5 my-1 mx-2"></div>
                 <button 
                    onClick={() => onLogout?.()} 
                    className="w-full px-6 py-3.5 text-left text-[#f15c6d] text-sm font-bold hover:bg-[#111b21] transition-colors flex items-center gap-3"
                 >
                   <svg xmlns="http://www.w3.org/2000/svg" className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" /></svg>
                   Sair
                 </button>
               </div>
             )}
          </div>
        </header>

        {/* Busca */}
        <div className="p-3 bg-[#111b21]">
          <div className="relative flex items-center bg-[#202c33] rounded-lg px-3">
             <div className="text-[#8696a0] mr-3 w-4 h-4"><svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg></div>
             <input 
               type="text" 
               placeholder="Pesquisar conversas" 
               className="w-full bg-transparent border-none py-2 text-sm text-[#d1d7db] outline-none placeholder-[#8696a0]"
             />
          </div>
        </div>

        {/* Lista de Contatos */}
        <div className="flex-1 overflow-y-auto">
          {conversations.length === 0 ? (
            <div className="p-10 text-center space-y-4 opacity-30">
               <Icons.User />
               <p className="text-xs font-bold uppercase tracking-widest">Nenhum contato</p>
            </div>
          ) : conversations.map((chat) => (
            <button 
              key={chat.id}
              onClick={() => setSelectedChat(chat)}
              className={`w-full h-[72px] flex items-center px-3 hover:bg-[#2a3942] transition-colors relative ${selectedChat?.id === chat.id ? 'bg-[#2a3942]' : ''}`}
            >
              <div className="w-12 h-12 rounded-full overflow-hidden shrink-0 bg-[#4f5e67] mr-3 flex items-center justify-center text-white/20">
                 {chat.participants[0].avatar ? <img src={chat.participants[0].avatar} className="w-full h-full object-cover" /> : <Icons.User />}
              </div>
              <div className="flex-1 border-b border-[#222d34] h-full flex flex-col justify-center min-w-0 pr-2">
                 <div className="flex justify-between items-center mb-1">
                    <span className="text-[#e9edef] text-[17px] font-normal truncate">{chat.participants[0].name}</span>
                    <span className="text-[12px] text-[#8696a0]">
                      {chat.messages.length > 0 ? new Date(chat.messages[chat.messages.length-1].timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}) : ''}
                    </span>
                 </div>
                 <div className="flex items-center gap-1 min-w-0">
                    {chat.messages.length > 0 && chat.messages[chat.messages.length-1].senderId === currentUser.id && renderCheckmarks(chat.messages[chat.messages.length-1].status)}
                    <p className="text-[#8696a0] text-sm truncate flex-1 text-left">
                      {DatabaseService.isUserTyping(chat.id, chat.participants[0].id) ? <span className="text-[#00a884] font-medium">digitando...</span> : (chat.messages.length > 0 ? chat.messages[chat.messages.length-1].content : <span className="italic opacity-50">Sem mensagens ainda</span>)}
                    </p>
                 </div>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Janela de Mensagens (Direita) */}
      <div className="flex-1 flex flex-col bg-[#0b141a]">
        {selectedChat ? (
          <>
            <header className="h-[59px] bg-[#202c33] flex items-center px-4 py-2 justify-between shrink-0 z-20 border-l border-white/5">
              <div className="flex items-center gap-3 cursor-pointer">
                 <div className="w-10 h-10 rounded-full overflow-hidden bg-[#4f5e67] flex items-center justify-center text-white/20">
                   {selectedChat.participants[0].avatar ? <img src={selectedChat.participants[0].avatar} className="w-full h-full object-cover" /> : <Icons.User />}
                 </div>
                 <div className="min-w-0">
                    <h4 className="text-[#e9edef] font-medium text-[16px] truncate leading-tight">{selectedChat.participants[0].name}</h4>
                    <p className="text-[13px] text-[#8696a0] leading-tight">{isOtherTyping ? <span className="text-[#00a884]">digitando...</span> : 'visto por último hoje às ' + new Date().getHours() + ':' + new Date().getMinutes()}</p>
                 </div>
              </div>
              <div className="flex gap-6 text-[#aebac1]">
                 <button className="hover:text-white transition-colors"><svg xmlns="http://www.w3.org/2000/svg" className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M15.5 14h-.79l-.28-.27A6.471 6.471 0 0 0 16 9.5 6.5 6.5 0 1 0 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/></svg></button>
                 <button className="hover:text-white transition-colors"><svg xmlns="http://www.w3.org/2000/svg" className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z"/></svg></button>
              </div>
            </header>

            <div ref={scrollRef} className="flex-1 overflow-y-auto px-[5%] py-6 space-y-3 chat-bg-pattern scroll-smooth">
              {selectedChat.messages.map((msg) => {
                const isMe = msg.senderId === currentUser.id;
                return (
                  <div key={msg.id} className={`flex ${isMe ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-[75%] px-3 py-1.5 rounded-lg shadow-sm relative group animate-in ${isMe ? 'bg-[#005c4b] text-[#e9edef] rounded-tr-none' : 'bg-[#202c33] text-[#e9edef] rounded-tl-none'}`}>
                       <p className="text-[14.2px] leading-relaxed pr-12 break-words">{msg.content}</p>
                       <div className="absolute bottom-1 right-1.5 flex items-center gap-1">
                          <span className="text-[10px] text-white/50">{new Date(msg.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
                          {isMe && renderCheckmarks(msg.status)}
                       </div>
                       {/* Tail effect */}
                       <div className={`absolute top-0 w-2 h-3 ${isMe ? '-right-2 bg-[#005c4b]' : '-left-2 bg-[#202c33]'}`} style={{ clipPath: isMe ? 'polygon(0 0, 100% 0, 0 100%)' : 'polygon(0 0, 100% 0, 100% 100%)' }} />
                    </div>
                  </div>
                );
              })}
              {isOtherTyping && (
                 <div className="flex justify-start">
                    <div className="bg-[#202c33] px-4 py-2 rounded-lg rounded-tl-none text-[#00a884] text-xs font-bold animate-pulse">digitando...</div>
                 </div>
              )}
            </div>

            <footer className="h-[62px] bg-[#202c33] flex items-center px-4 py-2 shrink-0 gap-3 border-l border-white/5">
              <button className="text-[#8696a0] hover:text-white transition-colors"><svg xmlns="http://www.w3.org/2000/svg" className="w-7 h-7" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm5 11h-4v4h-2v-4H7v-2h4V7h2v4h4v2z"/></svg></button>
              <input 
                type="text" 
                value={messageText}
                onChange={(e) => { setMessageText(e.target.value); DatabaseService.setTypingStatus(selectedChat.id, currentUser.id, e.target.value.length > 0); }}
                onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
                placeholder="Digite uma mensagem" 
                className="flex-1 bg-[#2a3942] rounded-xl px-4 py-2.5 text-[#d1d7db] outline-none text-sm placeholder-[#8696a0] border border-transparent focus:border-white/5 transition-all"
              />
              <button onClick={handleSendMessage} className={`p-2 transition-all ${messageText.trim() ? 'text-[#00a884] scale-110' : 'text-[#8696a0]'}`}>
                {messageText.trim() ? <Icons.Send /> : <Icons.Voice />}
              </button>
            </footer>
          </>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center text-center p-12 bg-[#222e35] border-l border-white/5 relative overflow-hidden">
             <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-[#00a884] to-transparent opacity-20"></div>
             <div className="w-32 h-32 mb-8 text-[#00a884] opacity-10 p-6 bg-[#00a884]/5 rounded-full scale-150 rotate-12">
                <Icons.Rocket />
             </div>
             <h3 className="text-[#e9edef] text-[32px] font-light mb-4">Zap Conect AI</h3>
             <p className="text-[#8696a0] max-w-sm text-sm leading-relaxed mb-10">
               Sincronize suas conversas e gerencie seus clientes com o poder da Inteligência Artificial Gemini 3.
             </p>
             <button 
                onClick={() => setShowAddContact(true)}
                className="bg-[#00a884] text-[#111b21] px-8 py-3 rounded-full font-bold uppercase tracking-widest text-xs hover:bg-[#06cf9c] transition-all active:scale-95 shadow-lg shadow-[#00a884]/20"
             >
                Começar Nova Conversa
             </button>
             <div className="flex items-center gap-2 text-[#8696a0] text-[11px] absolute bottom-10 opacity-30 uppercase tracking-widest font-black">
                <svg xmlns="http://www.w3.org/2000/svg" className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 00-2 2zm10-10V7a4 4 0 00-8 0v4h8z" /></svg>
                Criptografia de Ponta a Ponta
             </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ChatView;
