
import React from 'react';
import { AppView } from '../types';
import { Icons } from '../constants';

interface DashboardProps {
  setActiveView: (view: AppView) => void;
}

const DashboardView: React.FC<DashboardProps> = ({ setActiveView }) => {
  const stats = [
    { label: 'Mensagens Hoje', value: '12.430', color: 'teal', trend: '+5%' },
    { label: 'Taxa de Entrega', value: '99.8%', color: 'emerald', trend: 'Estável' },
    { label: 'Leads Ativos', value: '3.120', color: 'blue', trend: '+120 novos' },
    { label: 'Campanhas', value: '14', color: 'purple', trend: '2 em andamento' }
  ];

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-10 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <header className="flex flex-col gap-2">
        <h2 className="text-4xl font-black">Central de <span className="text-teal-400">Comando</span></h2>
        <p className="text-slate-500 font-medium">Monitoramento em tempo real do ecossistema Zap Conect</p>
      </header>

      <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((s) => (
          <div key={s.label} className="glass-panel p-6 rounded-3xl border border-white/5 hover:border-teal-500/20 transition-all group">
            <p className="text-[10px] text-slate-500 uppercase font-black tracking-widest mb-1 group-hover:text-teal-500 transition-colors">{s.label}</p>
            <div className="flex justify-between items-end">
              <p className="text-3xl font-black">{s.value}</p>
              <span className={`text-[10px] font-bold px-2 py-1 rounded-lg ${s.trend.startsWith('+') ? 'bg-emerald-500/10 text-emerald-400' : 'bg-slate-800 text-slate-400'}`}>
                {s.trend}
              </span>
            </div>
          </div>
        ))}
      </section>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 glass-panel p-8 rounded-[2rem] border-white/5 h-96 flex flex-col">
          <div className="flex justify-between items-center mb-6">
            <h3 className="font-bold text-lg">Tráfego de Mensagens</h3>
            <div className="flex gap-2">
              <span className="flex items-center gap-1.5 text-[10px] font-bold text-teal-400">
                <span className="w-2 h-2 rounded-full bg-teal-500"></span> Enviadas
              </span>
              <span className="flex items-center gap-1.5 text-[10px] font-bold text-blue-400">
                <span className="w-2 h-2 rounded-full bg-blue-500"></span> Recebidas
              </span>
            </div>
          </div>
          <div className="flex-1 flex items-end gap-3 px-2">
             {/* Simulação de Gráfico de Barras */}
             {[40, 60, 45, 90, 65, 80, 50, 70, 85, 95, 100, 75].map((h, i) => (
               <div key={i} className="flex-1 bg-slate-800/50 rounded-t-lg relative group">
                  <div 
                    className="absolute bottom-0 w-full bg-gradient-to-t from-teal-600/50 to-teal-400 rounded-t-lg transition-all duration-1000" 
                    style={{ height: `${h}%` }}
                  ></div>
                  <div className="absolute -top-6 left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity text-[8px] bg-slate-900 px-1 py-0.5 rounded">
                    {h * 100}
                  </div>
               </div>
             ))}
          </div>
        </div>

        <div className="glass-panel p-8 rounded-[2rem] border-white/5 flex flex-col">
          <h3 className="font-bold text-lg mb-6">Atalhos Rápidos</h3>
          <div className="space-y-4">
            <button onClick={() => setActiveView(AppView.CHAT)} className="w-full p-4 bg-slate-900/40 border border-slate-800 rounded-2xl flex items-center gap-4 hover:bg-slate-800/60 transition-all text-left">
              <div className="w-10 h-10 rounded-xl bg-teal-500/10 text-teal-400 flex items-center justify-center"><Icons.Chat /></div>
              <div>
                <p className="text-sm font-bold">Nova Conversa</p>
                <p className="text-[10px] text-slate-500">Chat 1x1 em tempo real</p>
              </div>
            </button>
            <button onClick={() => setActiveView(AppView.BUSINESS)} className="w-full p-4 bg-slate-900/40 border border-slate-800 rounded-2xl flex items-center gap-4 hover:bg-slate-800/60 transition-all text-left">
              <div className="w-10 h-10 rounded-xl bg-purple-500/10 text-purple-400 flex items-center justify-center"><Icons.Studio /></div>
              <div>
                <p className="text-sm font-bold">Lançar Campanha</p>
                <p className="text-[10px] text-slate-500">Envio em massa qualificado</p>
              </div>
            </button>
            <button onClick={() => setActiveView(AppView.CONTACTS)} className="w-full p-4 bg-slate-900/40 border border-slate-800 rounded-2xl flex items-center gap-4 hover:bg-slate-800/60 transition-all text-left">
              <div className="w-10 h-10 rounded-xl bg-blue-500/10 text-blue-400 flex items-center justify-center"><Icons.User /></div>
              <div>
                <p className="text-sm font-bold">Importar Base</p>
                <p className="text-[10px] text-slate-500">Gestão de contatos via CSV</p>
              </div>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DashboardView;
