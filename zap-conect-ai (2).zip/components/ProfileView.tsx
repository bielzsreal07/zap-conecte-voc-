
import React, { useState, useRef } from 'react';
import { User } from '../types';

interface ProfileProps {
  user: User;
  onUpdate: (updatedUser: User) => void;
}

const ProfileView: React.FC<ProfileProps> = ({ user, onUpdate }) => {
  const [name, setName] = useState(user.name);
  const [avatar, setAvatar] = useState(user.avatar || '');
  const [isSaving, setIsSaving] = useState(false);
  const [message, setMessage] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleSave = () => {
    setIsSaving(true);
    setTimeout(() => {
      onUpdate({ ...user, name, avatar });
      setIsSaving(false);
      setMessage('Perfil atualizado com sucesso!');
      setTimeout(() => setMessage(''), 3000);
    }, 800);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) {
        alert("A imagem deve ter no máximo 2MB");
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setAvatar(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="p-8 max-w-2xl mx-auto w-full animate-in fade-in slide-in-from-bottom-4 duration-500">
      <header className="mb-10 text-center">
        <h2 className="text-3xl font-black mb-2">Meu <span className="text-teal-400">Perfil</span></h2>
        <p className="text-slate-500 font-medium">Gerencie sua identidade no Zap Conect</p>
      </header>

      <div className="glass-panel p-10 rounded-[2.5rem] border-white/5 space-y-10 shadow-2xl">
        <div className="flex flex-col items-center gap-6">
          <div className="relative group cursor-pointer" onClick={() => fileInputRef.current?.click()}>
            <div className="w-40 h-40 rounded-full border-4 border-slate-800 overflow-hidden bg-slate-900 flex items-center justify-center shadow-2xl transition-all group-hover:border-teal-500/50">
              {avatar ? (
                <img src={avatar} className="w-full h-full object-cover" alt="Profile" />
              ) : (
                <div className="text-slate-700 flex flex-col items-center gap-2">
                  <svg xmlns="http://www.w3.org/2000/svg" className="w-12 h-12" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg>
                  <span className="text-[10px] font-black uppercase tracking-widest">Sem Foto</span>
                </div>
              )}
            </div>
            <div className="absolute bottom-2 right-2 bg-teal-500 text-slate-900 p-3 rounded-full shadow-xl group-hover:scale-110 transition-all">
              <svg xmlns="http://www.w3.org/2000/svg" className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
            </div>
            <input 
              type="file" 
              ref={fileInputRef} 
              className="hidden" 
              accept="image/*" 
              onChange={handleFileChange} 
            />
          </div>
          <p className="text-[10px] font-bold text-slate-500 uppercase tracking-[0.2em]">Toque na imagem para escolher uma foto da galeria</p>
        </div>

        <div className="space-y-6">
          <div className="space-y-2">
            <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">Nome Completo</label>
            <input 
              type="text" 
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full bg-slate-950/50 border border-slate-800 rounded-2xl px-6 py-4 outline-none focus:ring-2 focus:ring-teal-500/40 transition-all font-bold text-slate-200"
              placeholder="Como você quer ser chamado?"
            />
          </div>

          <div className="space-y-2">
            <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">E-mail de Cadastro</label>
            <div className="w-full bg-slate-950/20 border border-slate-800/50 rounded-2xl px-6 py-4 text-slate-500 font-medium text-sm flex items-center justify-between">
              {user.email}
              <svg xmlns="http://www.w3.org/2000/svg" className="w-4 h-4 opacity-30" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 00-2 2zm10-10V7a4 4 0 00-8 0v4h8z" /></svg>
            </div>
          </div>

          <div className="pt-6">
            <button 
              onClick={handleSave}
              disabled={isSaving || !name}
              className="w-full py-4 bg-teal-500 text-slate-950 font-black rounded-2xl hover:bg-teal-400 transition-all shadow-xl shadow-teal-500/10 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed uppercase tracking-widest"
            >
              {isSaving ? 'Processando...' : 'Atualizar Dados'}
            </button>
            {message && <p className="text-center text-teal-400 text-xs font-bold mt-4 animate-in zoom-in duration-300">{message}</p>}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProfileView;
