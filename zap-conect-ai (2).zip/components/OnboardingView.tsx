
import React, { useState } from 'react';
import emailjs from 'https://esm.sh/@emailjs/browser';
import { EMAILJS_SERVICE_ID, EMAILJS_TEMPLATE_ID, EMAILJS_PUBLIC_KEY, Icons } from '../constants';

interface OnboardingProps {
  userEmail: string;
  userName: string;
  onNumberSelected: (phone: string, code: string) => void;
}

const OnboardingView: React.FC<OnboardingProps> = ({ userEmail, userName, onNumberSelected }) => {
  const [choice, setChoice] = useState<'virtual' | 'chip' | null>(null);
  const [ddi, setDdi] = useState('+55');
  const [ddd, setDdd] = useState('11');
  const [chipPhone, setChipPhone] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleConfirm = async () => {
    if (choice === 'chip' && !chipPhone) {
      alert('Por favor, digite o seu número de telefone.');
      return;
    }

    setIsLoading(true);
    const code = Math.floor(100000 + Math.random() * 900000).toString();
    const phone = choice === 'virtual' 
      ? `${ddi} (${ddd}) 9${Math.floor(10000000 + Math.random() * 90000000)}` 
      : chipPhone;

    try {
      // Envia o código para o e-mail do cliente
      await emailjs.send(EMAILJS_SERVICE_ID, EMAILJS_TEMPLATE_ID, {
        to_email: userEmail,
        name: userName,
        user_name: userName,
        code: code,
        verification_code: code,
        message: code,
      }, EMAILJS_PUBLIC_KEY);
      
      onNumberSelected(phone, code);
    } catch (error) {
      console.error(error);
      alert('Erro ao enviar código de verificação para o e-mail. Verifique sua conexão.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#111b21] flex items-center justify-center p-6 text-[#e9edef] font-sans">
      <div className="w-full max-w-2xl space-y-8 animate-in fade-in zoom-in-95">
        <div className="text-center space-y-4">
          <div className="w-24 h-24 bg-[#00a884] rounded-[2rem] flex items-center justify-center mx-auto p-5 text-[#111b21] shadow-2xl shadow-[#00a884]/20">
            <Icons.Rocket />
          </div>
          <h2 className="text-4xl font-bold tracking-tight">Configure sua conta</h2>
          <p className="text-[#8696a0] font-medium text-lg">Escolha como você quer se conectar ao sistema</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <button 
            onClick={() => setChoice('virtual')}
            className={`p-10 rounded-3xl border-2 transition-all text-left bg-[#222e35] relative overflow-hidden group ${
              choice === 'virtual' ? 'border-[#00a884] bg-[#2a3942]' : 'border-white/5 hover:border-white/10'
            }`}
          >
            <div className={`w-14 h-14 rounded-2xl flex items-center justify-center mb-6 transition-all ${
              choice === 'virtual' ? 'bg-[#00a884] text-[#111b21]' : 'bg-[#2a3942] text-[#8696a0]'
            }`}>
               <svg xmlns="http://www.w3.org/2000/svg" className="w-7 h-7" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" /></svg>
            </div>
            <h3 className="font-bold text-xl mb-2">Número Virtual</h3>
            <p className="text-sm text-[#8696a0] leading-relaxed">Gere uma identidade digital instantânea e exclusiva.</p>
          </button>

          <button 
            onClick={() => setChoice('chip')}
            className={`p-10 rounded-3xl border-2 transition-all text-left bg-[#222e35] relative overflow-hidden group ${
              choice === 'chip' ? 'border-[#00a884] bg-[#2a3942]' : 'border-white/5 hover:border-white/10'
            }`}
          >
            <div className={`w-14 h-14 rounded-2xl flex items-center justify-center mb-6 transition-all ${
              choice === 'chip' ? 'bg-[#00a884] text-[#111b21]' : 'bg-[#2a3942] text-[#8696a0]'
            }`}>
              <svg xmlns="http://www.w3.org/2000/svg" className="w-7 h-7" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z" /></svg>
            </div>
            <h3 className="font-bold text-xl mb-2">Seu Número</h3>
            <p className="text-sm text-[#8696a0] leading-relaxed">Vincule o número do chip que você já utiliza.</p>
          </button>
        </div>

        {/* Inputs dinâmicos baseados na escolha */}
        {choice && (
          <div className="bg-[#222e35] p-8 rounded-3xl border border-white/5 space-y-6 animate-in slide-in-from-top-4">
            <h4 className="font-bold text-[#00a884] uppercase text-xs tracking-widest">Informações Adicionais</h4>
            
            {choice === 'virtual' ? (
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-[#8696a0] uppercase ml-1">País (DDI)</label>
                  <input 
                    type="text" 
                    value={ddi} 
                    onChange={e => setDdi(e.target.value)}
                    className="w-full bg-[#2a3942] border-none rounded-xl px-5 py-4 text-[#e9edef] outline-none focus:ring-2 focus:ring-[#00a884]/50"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-[#8696a0] uppercase ml-1">Região (DDD)</label>
                  <input 
                    type="text" 
                    value={ddd} 
                    onChange={e => setDdd(e.target.value)}
                    className="w-full bg-[#2a3942] border-none rounded-xl px-5 py-4 text-[#e9edef] outline-none focus:ring-2 focus:ring-[#00a884]/50"
                  />
                </div>
              </div>
            ) : (
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-[#8696a0] uppercase ml-1">Seu Telefone com DDD</label>
                <input 
                  type="text" 
                  placeholder="+55 (11) 99999-9999"
                  value={chipPhone} 
                  onChange={e => setChipPhone(e.target.value)}
                  className="w-full bg-[#2a3942] border-none rounded-xl px-5 py-4 text-[#e9edef] outline-none focus:ring-2 focus:ring-[#00a884]/50"
                />
              </div>
            )}
            <p className="text-[11px] text-[#8696a0] text-center italic">Ao confirmar, um código de verificação será enviado para <b>{userEmail}</b></p>
          </div>
        )}

        <div className="flex justify-center pt-4">
          <button 
            disabled={!choice || isLoading}
            onClick={handleConfirm}
            className="px-20 py-5 bg-[#00a884] text-[#111b21] font-black rounded-full hover:bg-[#06cf9c] transition-all disabled:opacity-20 uppercase tracking-widest active:scale-95 shadow-2xl shadow-[#00a884]/20 text-lg"
          >
            {isLoading ? (
              <div className="flex items-center gap-3">
                <div className="w-5 h-5 border-2 border-[#111b21] border-t-transparent rounded-full animate-spin"></div>
                ENVIANDO CÓDIGO...
              </div>
            ) : 'CONFIRMAR E RECEBER CÓDIGO'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default OnboardingView;
