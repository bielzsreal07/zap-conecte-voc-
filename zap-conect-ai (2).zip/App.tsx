
import React, { useState, useEffect } from 'react';
import { AppView, User } from './types';
import { Icons } from './constants';
import { DatabaseService } from './services/database';
import AuthView from './components/AuthView';
import OnboardingView from './components/OnboardingView';
import VerificationView from './components/VerificationView';
import ChatView from './components/ChatView';
import ContactsView from './components/ContactsView';
import ProfileView from './components/ProfileView';
import BusinessView from './components/BusinessView';

const App: React.FC = () => {
  const [activeView, setActiveView] = useState<AppView>(AppView.AUTH);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [generatedCode, setGeneratedCode] = useState<string | null>(null);

  useEffect(() => {
    DatabaseService.initSeed();
    const sessionUser = DatabaseService.getSession();
    
    if (sessionUser) {
      // Busca dados atualizados no "banco" para garantir status de verificação correto
      const user = DatabaseService.getUserByEmail(sessionUser.email);
      if (user) {
        setCurrentUser(user);
        // Lógica de Roteamento Blindado
        if (user.verified && user.phone) {
          setActiveView(AppView.CHAT);
        } else if (user.phone && !user.verified) {
          setActiveView(AppView.VERIFY);
        } else {
          setActiveView(AppView.ONBOARDING);
        }
      }
    }
  }, []);

  const handleAuthSuccess = (userFromAuth: User) => {
    // Sempre verifica o estado no banco de dados para o e-mail fornecido
    const user = DatabaseService.getUserByEmail(userFromAuth.email) || userFromAuth;
    setCurrentUser(user);
    DatabaseService.setSession(user);
    
    if (user.verified && user.phone) {
      setActiveView(AppView.CHAT);
    } else if (user.phone && !user.verified) {
      setActiveView(AppView.VERIFY);
    } else {
      setActiveView(AppView.ONBOARDING);
    }
  };

  const handleLogout = () => {
    DatabaseService.clearSession();
    setCurrentUser(null);
    setActiveView(AppView.AUTH);
  };

  if (activeView === AppView.AUTH) {
    return <AuthView onAuthSuccess={handleAuthSuccess} />;
  }

  if (activeView === AppView.ONBOARDING) {
    return <OnboardingView 
      userEmail={currentUser?.email || ''} 
      userName={currentUser?.name || ''}
      onNumberSelected={(phone, code) => {
        const updatedUser = { ...currentUser!, phone };
        setCurrentUser(updatedUser);
        setGeneratedCode(code);
        // Persiste o número escolhido imediatamente no banco
        DatabaseService.saveUser(updatedUser);
        setActiveView(AppView.VERIFY);
      }} 
    />;
  }

  if (activeView === AppView.VERIFY) {
    return <VerificationView 
      userEmail={currentUser?.email || ''} 
      correctCode={generatedCode || ''}
      onVerified={() => {
        if (currentUser) {
          const verifiedUser = { ...currentUser, verified: true };
          setCurrentUser(verifiedUser);
          // Persiste a verificação final - agora o usuário nunca mais volta
          DatabaseService.saveUser(verifiedUser);
          setActiveView(AppView.CHAT);
        }
      }} 
    />;
  }

  const navItems = [
    { id: AppView.CHAT, label: 'Conversas', icon: Icons.Chat },
    { id: AppView.CONTACTS, label: 'Agenda', icon: Icons.User },
    { id: AppView.BUSINESS, label: 'Transmissão', icon: Icons.Bot },
    { id: AppView.PROFILE, label: 'Perfil', icon: Icons.Settings },
  ];

  const renderView = () => {
    switch (activeView) {
      case AppView.CHAT: return <ChatView currentUser={currentUser!} onNavigate={setActiveView} onLogout={handleLogout} />;
      case AppView.CONTACTS: return <ContactsView onSelectChat={() => setActiveView(AppView.CHAT)} />;
      case AppView.BUSINESS: return <BusinessView />;
      case AppView.PROFILE: return <ProfileView user={currentUser!} onUpdate={(u) => { setCurrentUser(u); DatabaseService.saveUser(u); }} />;
      default: return <ChatView currentUser={currentUser!} onNavigate={setActiveView} onLogout={handleLogout} />;
    }
  };

  return (
    <div className="flex h-screen bg-[#0b141a] overflow-hidden text-[#e9edef] font-sans">
      <aside className="w-16 bg-[#202c33] flex flex-col items-center py-4 border-r border-white/5 z-30 shrink-0">
        <div className="w-10 h-10 rounded-xl bg-[#00a884] flex items-center justify-center shadow-lg shadow-[#00a884]/20 mb-6 p-2 text-[#111b21]">
          <Icons.Rocket />
        </div>

        <nav className="flex-1 space-y-4">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveView(item.id)}
              title={item.label}
              className={`p-3 rounded-xl transition-all relative group ${
                activeView === item.id ? 'bg-white/10 text-[#00a884]' : 'text-[#8696a0] hover:text-[#e9edef]'
              }`}
            >
              <item.icon />
              {activeView === item.id && <div className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-6 bg-[#00a884] rounded-r-full" />}
            </button>
          ))}
        </nav>

        <div className="mt-auto space-y-4">
           <button onClick={handleLogout} title="Sair" className="p-3 text-[#8696a0] hover:text-red-400 transition-all">
             <svg xmlns="http://www.w3.org/2000/svg" className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" /></svg>
           </button>
           <button onClick={() => setActiveView(AppView.PROFILE)} className="w-10 h-10 rounded-full border border-white/10 overflow-hidden bg-[#2a3942] flex items-center justify-center text-[#8696a0] hover:scale-105 transition-all">
              {currentUser?.avatar ? <img src={currentUser.avatar} className="w-full h-full object-cover" alt="" /> : <Icons.User />}
           </button>
        </div>
      </aside>

      <main className="flex-1 relative flex flex-col overflow-hidden">
        {renderView()}
      </main>
    </div>
  );
};

export default App;
