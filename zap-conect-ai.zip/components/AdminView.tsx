
import React, { useState } from 'react';
import { Icons } from '../constants';

const AdminView: React.FC = () => {
  const [logs] = useState([
    { id: '1', event: 'Disparo de Campanha C1 Iniciado', level: 'info', timestamp: Date.now() - 5000 },
    { id: '2', event: 'Bloqueio de Tentativa de Flood (+55 11 99912-3321)', level: 'warning', timestamp: Date.now() - 3600000 },
    { id: '3', event: 'Certificado SSL Renovado', level: 'info', timestamp: Date.now() - 86400000 },
    { id: '4', event: 'Falha na entrega de SMS OTP (Gateway Timeout)', level: 'error', timestamp: Date.now() - 172800000 },
  ]);

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-10 animate-in fade-in duration-500">
      <header className="flex justify-between items-center">
        <div>
          <h2 className="text-4xl font-black">Segurança & <span className="text-red-400">Monitoramento</span></h2>
          <p className="text-slate-500 font-medium">Logs críticos e integridade do Zap Conect</p>
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 glass-panel rounded-[2rem] border-white/5 overflow-hidden">
          <div className="p-6 bg-slate-900/40 border-b border-slate-800/60">
            <h3 className="font-bold">Logs de Eventos em Tempo Real</h3>
          </div>
          <div className="p-4 space-y-2">
            {logs.map(log => (
              <div key={log.id} className="flex gap-4 p-4 bg-slate-900/40 rounded-2xl border border-white/5 hover:bg-slate-800/40 transition-all">
                <div className={`w-2 h-2 rounded-full mt-1.5 flex-shrink-0 ${
                  log.level === 'error' ? 'bg-red-500 shadow-lg shadow-red-500/40' : 
                  log.level === 'warning' ? 'bg-amber-500 shadow-lg shadow-amber-500/40' : 
                  'bg-teal-500 shadow-lg shadow-teal-500/40'
                }`}></div>
                <div className="flex-1">
                  <p className="text-xs font-bold">{log.event}</p>
                  <p className="text-[9px] text-slate-500 mt-1 uppercase font-black">{new Date(log.timestamp).toLocaleString()}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="space-y-8">
          <div className="glass-panel p-8 rounded-[2rem] border-white/5">
            <h3 className="font-bold text-lg mb-6">Saúde do Sistema</h3>
            <div className="space-y-6">
              <div className="space-y-2">
                <div className="flex justify-between text-[10px] font-black uppercase text-slate-500 tracking-widest">
                  <span>Uso de CPU</span>
                  <span className="text-teal-400">22%</span>
                </div>
                <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                  <div className="h-full bg-teal-500 w-[22%]" />
                </div>
              </div>
              <div className="space-y-2">
                <div className="flex justify-between text-[10px] font-black uppercase text-slate-500 tracking-widest">
                  <span>Memória Redis</span>
                  <span className="text-blue-400">1.2 GB / 8 GB</span>
                </div>
                <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                  <div className="h-full bg-blue-500 w-[15%]" />
                </div>
              </div>
              <div className="space-y-2">
                <div className="flex justify-between text-[10px] font-black uppercase text-slate-500 tracking-widest">
                  <span>Queue (Filas)</span>
                  <span className="text-emerald-400">Ociosa</span>
                </div>
                <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                  <div className="h-full bg-emerald-500 w-[5%]" />
                </div>
              </div>
            </div>
          </div>

          <div className="glass-panel p-8 rounded-[2rem] border-red-500/10">
            <h3 className="font-bold text-lg text-red-400 mb-4">Ações de Risco</h3>
            <div className="space-y-3">
              <button className="w-full py-3 bg-red-500/5 border border-red-500/20 text-red-400 text-[10px] font-black uppercase tracking-widest rounded-xl hover:bg-red-500/10 transition-all">Limpar Cache Global</button>
              <button className="w-full py-3 bg-red-500/5 border border-red-500/20 text-red-400 text-[10px] font-black uppercase tracking-widest rounded-xl hover:bg-red-500/10 transition-all">Forçar Logout Todos Usuários</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminView;
