
import React, { useState } from 'react';
import { GeneratedAsset } from '../types';
import { GeminiService } from '../services/geminiService';
import { Icons } from '../constants';

interface StudioViewProps {
  setAssets: React.Dispatch<React.SetStateAction<GeneratedAsset[]>>;
}

const StudioView: React.FC<StudioViewProps> = ({ setAssets }) => {
  const [prompt, setPrompt] = useState('');
  const [type, setType] = useState<'image' | 'video'>('image');
  const [quality, setQuality] = useState<'standard' | 'high'>('standard');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [currentResult, setCurrentResult] = useState<GeneratedAsset | null>(null);

  const handleGenerate = async () => {
    if (!prompt.trim() || isLoading) return;
    
    setIsLoading(true);
    setError(null);
    setCurrentResult(null);

    try {
      let url = '';
      if (type === 'image') {
        // High quality images use gemini-3-pro-image-preview which requires manual API key selection
        if (quality === 'high') {
          const hasKey = await (window as any).aistudio?.hasSelectedApiKey();
          if (!hasKey) {
            await (window as any).aistudio?.openSelectKey();
          }
        }
        url = await GeminiService.generateImage(prompt, quality === 'high');
      } else {
        // Veo model requires manual API key selection if needed
        const hasKey = await (window as any).aistudio?.hasSelectedApiKey();
        if (!hasKey) {
          await (window as any).aistudio?.openSelectKey();
        }
        url = await GeminiService.generateVideo(prompt, quality === 'high' ? '1080p' : '720p');
      }

      const newAsset: GeneratedAsset = {
        id: Date.now().toString(),
        type: type,
        url: url,
        prompt: prompt,
        timestamp: Date.now(),
      };

      setCurrentResult(newAsset);
      setAssets(prev => [newAsset, ...prev]);
    } catch (err: any) {
      console.error(err);
      if (err.message?.includes('Requested entity was not found')) {
        await (window as any).aistudio?.openSelectKey();
        setError("Please re-select your API key and try again.");
      } else {
        setError("Synthesis failed. Please try a different prompt or check your connection.");
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
      {/* Control Panel */}
      <div className="lg:col-span-1 space-y-6">
        <div className="glass-panel p-6 rounded-3xl space-y-6">
          <h3 className="text-xl font-bold text-slate-100 flex items-center gap-2">
            <Icons.Studio /> Configuration
          </h3>

          <div className="space-y-4">
            <label className="block text-sm font-medium text-slate-400">Asset Type</label>
            <div className="flex p-1 bg-slate-800 rounded-xl">
              <button 
                onClick={() => setType('image')}
                className={`flex-1 py-2 rounded-lg text-sm font-medium transition-all ${type === 'image' ? 'bg-slate-700 text-white shadow-sm' : 'text-slate-500 hover:text-slate-300'}`}
              >
                Image
              </button>
              <button 
                onClick={() => setType('video')}
                className={`flex-1 py-2 rounded-lg text-sm font-medium transition-all ${type === 'video' ? 'bg-slate-700 text-white shadow-sm' : 'text-slate-500 hover:text-slate-300'}`}
              >
                Video
              </button>
            </div>
          </div>

          <div className="space-y-4">
            <label className="block text-sm font-medium text-slate-400">Target Fidelity</label>
            <div className="flex p-1 bg-slate-800 rounded-xl">
              <button 
                onClick={() => setQuality('standard')}
                className={`flex-1 py-2 rounded-lg text-sm font-medium transition-all ${quality === 'standard' ? 'bg-slate-700 text-white shadow-sm' : 'text-slate-500 hover:text-slate-300'}`}
              >
                Fast
              </button>
              <button 
                onClick={() => setQuality('high')}
                className={`flex-1 py-2 rounded-lg text-sm font-medium transition-all ${quality === 'high' ? 'bg-slate-700 text-white shadow-sm' : 'text-slate-500 hover:text-slate-300'}`}
              >
                Pro
              </button>
            </div>
            <p className="text-[10px] text-slate-500">
              {quality === 'high' ? 'Pro uses Gemini 3 Pro models for higher resolution but takes longer.' : 'Fast uses Flash models for near-instant results.'}
            </p>
          </div>

          <div className="space-y-4">
            <label className="block text-sm font-medium text-slate-400">Description</label>
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="e.g. A futuristic cyberpunk city in 4k with neon lighting and rainy streets..."
              className="w-full bg-slate-900 border border-slate-800 text-slate-200 rounded-xl p-4 focus:outline-none focus:ring-2 focus:ring-purple-500/40 min-h-[120px]"
            />
          </div>

          <button
            onClick={handleGenerate}
            disabled={!prompt.trim() || isLoading}
            className={`w-full py-4 rounded-xl font-bold flex items-center justify-center gap-2 transition-all ${
              isLoading 
              ? 'bg-slate-800 text-slate-500 cursor-not-allowed' 
              : 'bg-gradient-to-r from-purple-600 to-blue-600 text-white hover:shadow-lg hover:shadow-purple-500/20'
            }`}
          >
            {isLoading ? (
              <>
                <div className="w-5 h-5 border-2 border-slate-600 border-t-slate-400 rounded-full animate-spin"></div>
                Synthesizing...
              </>
            ) : (
              <>
                <Icons.Studio /> Generate {type === 'image' ? 'Image' : 'Video'}
              </>
            )}
          </button>

          {error && (
            <div className="p-4 bg-red-500/10 border border-red-500/20 rounded-xl">
              <p className="text-sm text-red-400">{error}</p>
            </div>
          )}
        </div>
      </div>

      {/* Result Display */}
      <div className="lg:col-span-2">
        <div className="glass-panel h-full min-h-[500px] rounded-3xl overflow-hidden flex flex-col">
          <div className="p-6 border-b border-slate-800 flex justify-between items-center">
            <span className="text-sm font-medium text-slate-400">Synthesizer Output</span>
            {currentResult && (
               <button onClick={() => window.open(currentResult.url, '_blank')} className="text-xs text-blue-400 hover:underline">Download Original</button>
            )}
          </div>
          <div className="flex-1 bg-black/40 flex items-center justify-center p-8 relative">
            {isLoading ? (
              <div className="text-center space-y-4">
                <div className="inline-block relative">
                   <div className="w-24 h-24 rounded-full border-4 border-slate-800 border-t-purple-500 animate-spin"></div>
                   <div className="absolute inset-0 flex items-center justify-center">
                     <Icons.Studio />
                   </div>
                </div>
                <p className="text-slate-400 animate-pulse">Consulting the creative nodes...</p>
              </div>
            ) : currentResult ? (
              <div className="w-full h-full flex flex-col items-center">
                <div className="flex-1 w-full relative group">
                  {currentResult.type === 'image' ? (
                    <img src={currentResult.url} alt={currentResult.prompt} className="w-full h-full object-contain rounded-xl" />
                  ) : (
                    <video src={currentResult.url} controls className="w-full h-full object-contain rounded-xl" />
                  )}
                </div>
                <div className="mt-6 p-4 bg-slate-900/50 rounded-xl border border-slate-800 w-full">
                  <p className="text-xs text-slate-500 mb-1">Generated Prompt:</p>
                  <p className="text-sm text-slate-300 italic">"{currentResult.prompt}"</p>
                </div>
              </div>
            ) : (
              <div className="text-center space-y-4 max-w-sm">
                <div className="w-20 h-20 bg-slate-800/50 rounded-full flex items-center justify-center mx-auto text-slate-600">
                   <Icons.Studio />
                </div>
                <h4 className="text-lg font-medium text-slate-500">No output generated yet</h4>
                <p className="text-sm text-slate-600">Configure your parameters on the left and click generate to see the magic happen.</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default StudioView;
