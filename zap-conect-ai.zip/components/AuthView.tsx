
import React, { useState } from 'react';
import { User } from '../types';
import { DatabaseService } from '../services/database';
import { Icons } from '../constants';

interface AuthProps {
  onAuthSuccess: (user: User) => void;
}

const AuthView: React.FC<AuthProps> = ({ onAuthSuccess }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.includes('@')) { setError('E-mail inválido.'); return; }
    if (password.length < 6) { setError('A senha deve ter pelo menos 6 dígitos.'); return; }
    
    setIsLoading(true);
    setError(null);

    try {
      const existingUser = DatabaseService.getUserByEmail(email);
      
      if (existingUser) {
        if (existingUser.password === password) {
          onAuthSuccess(existingUser);
        } else {
          setError('Senha incorreta.');
          setIsLoading(false);
        }
      } else {
        // Primeiro Acesso: Criação e Salvamento Definitivo
        const newUser: User = {
          id: 'u-' + Math.random().toString(36).substr(2, 9),
          name: email.split('@')[0],
          email: email,
          password: password,
          isOnline: true,
          isBusiness: false,
          verified: false,
          avatar: ""
        };
        DatabaseService.saveUser(newUser);
        onAuthSuccess(newUser);
      }
    } catch (err) {
      setError('Erro no sistema.');
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#111b21] flex items-center justify-center p-6 font-sans">
      <div className="w-full max-w-[450px] bg-[#222e35] p-12 rounded-lg shadow-2xl border border-white/5 relative overflow-hidden">
        <div className="text-center mb-10">
          <div className="w-20 h-20 bg-[#00a884] rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-xl p-4 text-[#111b21]">
            <Icons.Rocket />
          </div>
          <h1 className="text-3xl font-bold mb-2 tracking-tight text-[#e9edef]">Zap Conect AI</h1>
          <p className="text-[#8696a0] text-sm font-medium">Conecte-se para começar a disparar</p>
        </div>

        <form onSubmit={handleLogin} className="space-y-6">
          <div className="space-y-1.5">
            <label className="text-[12px] font-bold text-[#00a884] uppercase tracking-wider ml-1">E-mail</label>
            <input 
              type="email" 
              value={email}
              onChange={(e) => { setEmail(e.target.value); setError(null); }}
              placeholder="Digite seu e-mail" 
              className="w-full bg-[#2a3942] border-none rounded-lg px-5 py-3.5 outline-none focus:ring-2 focus:ring-[#00a884]/40 transition-all text-[#d1d7db] placeholder-[#8696a0]"
            />
          </div>

          <div className="space-y-1.5">
            <label className="text-[12px] font-bold text-[#00a884] uppercase tracking-wider ml-1">Senha</label>
            <input 
              type="password" 
              value={password}
              onChange={(e) => { setPassword(e.target.value); setError(null); }}
              placeholder="Mínimo 6 caracteres" 
              className="w-full bg-[#2a3942] border-none rounded-lg px-5 py-3.5 outline-none focus:ring-2 focus:ring-[#00a884]/40 transition-all text-[#d1d7db] placeholder-[#8696a0]"
            />
          </div>

          {error && <p className="text-[#f15c6d] text-xs font-bold text-center animate-pulse">{error}</p>}

          <button 
            type="submit"
            disabled={isLoading}
            className="w-full py-4 bg-[#00a884] text-[#111b21] font-bold rounded-full hover:bg-[#06cf9c] transition-all flex items-center justify-center gap-2 shadow-lg shadow-[#00a884]/10 active:scale-95 disabled:opacity-50"
          >
            {isLoading ? <div className="w-5 h-5 border-2 border-[#111b21] border-t-transparent rounded-full animate-spin"></div> : 'ENTRAR / CADASTRAR'}
          </button>
        </form>

        <div className="mt-8 text-center text-[11px] text-[#8696a0] leading-relaxed uppercase tracking-widest font-bold">
           Login seguro com criptografia de ponta a ponta
        </div>
      </div>
    </div>
  );
};

export default AuthView;
