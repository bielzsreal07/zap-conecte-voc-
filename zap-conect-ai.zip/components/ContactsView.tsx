
import React, { useState, useEffect } from 'react';
import { User } from '../types';
import { Icons } from '../constants';
import { DatabaseService } from '../services/database';

interface ContactsProps {
  onSelectChat: () => void;
}

const ContactsView: React.FC<ContactsProps> = ({ onSelectChat }) => {
  const [contacts, setContacts] = useState<User[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isAdding, setIsAdding] = useState(false);
  const [newContact, setNewContact] = useState({ name: '', email: '', phone: '' });

  useEffect(() => {
    loadContacts();
  }, []);

  const loadContacts = () => {
    setContacts(DatabaseService.getAllUsers());
  };

  const handleAddContact = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newContact.name || !newContact.email) return;

    const contactUser: User = {
      id: 'c-' + Math.random().toString(36).substr(2, 9),
      name: newContact.name,
      email: newContact.email,
      phone: newContact.phone,
      isOnline: false,
      isBusiness: false,
      avatar: ""
    };

    DatabaseService.saveUser(contactUser);
    setNewContact({ name: '', email: '', phone: '' });
    setIsAdding(false);
    loadContacts();
  };

  const filteredContacts = contacts.filter(c => 
    c.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    c.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-10 animate-in fade-in duration-500">
      <header className="flex justify-between items-center">
        <div>
          <h2 className="text-4xl font-black">Minha <span className="text-teal-400">Agenda</span></h2>
          <p className="text-slate-500 font-medium">Gerencie seus clientes e contatos salvos</p>
        </div>
        <button 
          onClick={() => setIsAdding(true)}
          className="bg-teal-500 text-slate-900 px-6 py-3 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-teal-400 transition-all flex items-center gap-2 shadow-lg shadow-teal-500/20 active:scale-95"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M12 4v16m8-8H4" /></svg>
          Novo Contato
        </button>
      </header>

      {isAdding && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-6 bg-slate-950/80 backdrop-blur-sm">
          <form onSubmit={handleAddContact} className="glass-panel w-full max-w-md p-8 rounded-[2.5rem] border-white/10 animate-in zoom-in-95">
            <h3 className="text-xl font-black mb-6">Adicionar Novo Contato</h3>
            <div className="space-y-4">
              <input 
                required
                placeholder="Nome Completo"
                className="w-full bg-slate-900 border border-slate-800 rounded-xl px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-teal-500/30"
                value={newContact.name}
                onChange={e => setNewContact({...newContact, name: e.target.value})}
              />
              <input 
                required
                type="email"
                placeholder="E-mail do Cliente"
                className="w-full bg-slate-900 border border-slate-800 rounded-xl px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-teal-500/30"
                value={newContact.email}
                onChange={e => setNewContact({...newContact, email: e.target.value})}
              />
              <input 
                placeholder="Telefone (Opcional)"
                className="w-full bg-slate-900 border border-slate-800 rounded-xl px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-teal-500/30"
                value={newContact.phone}
                onChange={e => setNewContact({...newContact, phone: e.target.value})}
              />
            </div>
            <div className="flex gap-3 mt-8">
              <button type="button" onClick={() => setIsAdding(false)} className="flex-1 py-3 text-slate-500 font-bold hover:text-white transition-all">Cancelar</button>
              <button type="submit" className="flex-1 py-3 bg-teal-500 text-slate-900 font-black rounded-xl hover:bg-teal-400 transition-all">SALVAR</button>
            </div>
          </form>
        </div>
      )}

      <div className="glass-panel p-4 rounded-3xl border-white/5 flex gap-4">
        <div className="relative flex-1">
          <input 
            type="text" 
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Pesquisar contatos salvos..." 
            className="w-full bg-slate-900/50 border border-slate-800 rounded-2xl py-4 pl-12 pr-4 text-sm outline-none focus:ring-2 focus:ring-teal-500/20 transition-all text-slate-200"
          />
          <div className="absolute left-4 top-4 text-slate-500"><Icons.Chat /></div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {filteredContacts.map((contact) => (
          <div key={contact.id} className="glass-panel p-6 rounded-[2rem] border-white/5 hover:border-teal-500/20 transition-all group relative overflow-hidden">
            <div className="flex flex-col items-center text-center">
              <div className="w-20 h-20 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-center mb-4 text-slate-600 group-hover:scale-105 transition-all">
                {contact.avatar ? <img src={contact.avatar} className="w-full h-full object-cover rounded-2xl" /> : <Icons.User />}
              </div>
              <h4 className="font-bold text-base truncate w-full">{contact.name}</h4>
              <p className="text-[10px] text-slate-500 mb-6 truncate w-full">{contact.email}</p>
              <button 
                onClick={onSelectChat}
                className="w-full py-3 bg-slate-800 text-slate-300 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-teal-500 hover:text-slate-900 transition-all active:scale-95"
              >
                Conversar
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ContactsView;
