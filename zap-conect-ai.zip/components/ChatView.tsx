
import React, { useState, useRef, useEffect } from 'react';
import { User, ChatMessage, Conversation } from '../types';
import { Icons } from '../constants';
import { DatabaseService } from '../services/database';

interface ChatProps {
  currentUser: User;
}

const ChatView: React.FC<ChatProps> = ({ currentUser }) => {
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [selectedChat, setSelectedChat] = useState<Conversation | null>(null);
  const [messageText, setMessageText] = useState('');
  const [isOtherTyping, setIsOtherTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const typingTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  const loadData = () => {
    const allUsers = DatabaseService.getAllUsers().filter((u: User) => u.id !== currentUser.id);
    
    const updatedConversations: Conversation[] = allUsers.map((u: User) => {
      const chatId = [currentUser.id, u.id].sort().join('_');
      DatabaseService.markMessagesAsDelivered(chatId, currentUser.id);

      return {
        id: chatId,
        participants: [u],
        messages: DatabaseService.getMessagesForChat(chatId),
        unreadCount: 0
      };
    });

    setConversations(updatedConversations);
    
    if (selectedChat) {
      const currentSelected = updatedConversations.find(c => c.id === selectedChat.id);
      if (currentSelected) {
        setSelectedChat(currentSelected);
        const otherParticipant = currentSelected.participants[0];
        setIsOtherTyping(DatabaseService.isUserTyping(currentSelected.id, otherParticipant.id));
      }
    }
  };

  useEffect(() => {
    loadData();
    const interval = setInterval(loadData, 2000);
    return () => clearInterval(interval);
  }, [currentUser.id, selectedChat?.id]);

  useEffect(() => {
    if (selectedChat) {
      DatabaseService.markMessagesAsRead(selectedChat.id, currentUser.id);
    }
  }, [selectedChat?.id, selectedChat?.messages.length]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [selectedChat?.messages, isOtherTyping]);

  const handleTyping = (text: string) => {
    setMessageText(text);
    if (!selectedChat) return;
    DatabaseService.setTypingStatus(selectedChat.id, currentUser.id, true);
    if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
    typingTimeoutRef.current = setTimeout(() => {
      if (selectedChat) {
        DatabaseService.setTypingStatus(selectedChat.id, currentUser.id, false);
      }
    }, 3000);
  };

  const handleSendMessage = () => {
    if (!messageText.trim() || !selectedChat) return;

    const newMessage: ChatMessage = {
      id: Date.now().toString(),
      chatId: selectedChat.id,
      senderId: currentUser.id,
      content: messageText,
      type: 'text',
      status: 'sent',
      timestamp: Date.now()
    };

    if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
    DatabaseService.setTypingStatus(selectedChat.id, currentUser.id, false);
    DatabaseService.saveMessage(newMessage);
    loadData();
    setMessageText('');
  };

  const renderCheckmarks = (status: 'sent' | 'delivered' | 'read') => {
    switch (status) {
      case 'read':
        return <span className="text-[#53bdeb] font-bold text-[13px] leading-none">✓✓</span>;
      case 'delivered':
        return <span className="text-[#8696a0] font-bold text-[13px] leading-none">✓✓</span>;
      default:
        return <span className="text-[#8696a0] font-bold text-[13px] leading-none">✓</span>;
    }
  };

  return (
    <div className="flex h-full bg-[#0b141a]">
      {/* Lista de Conversas (Esquerda) */}
      <div className="w-[400px] border-r border-[#2a3942] flex flex-col bg-[#111b21]">
        <header className="h-[59px] bg-[#202c33] flex items-center justify-between px-4 py-2 shrink-0">
          <h2 className="text-[#e9edef] font-bold text-xl">Conversas</h2>
          <div className="flex gap-4 text-[#aebac1]">
             <svg xmlns="http://www.w3.org/2000/svg" className="w-6 h-6 cursor-pointer" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z"/></svg>
             <svg xmlns="http://www.w3.org/2000/svg" className="w-6 h-6 cursor-pointer" fill="currentColor" viewBox="0 0 24 24"><path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/></svg>
          </div>
        </header>

        <div className="p-3 bg-[#111b21]">
          <div className="relative flex items-center bg-[#202c33] rounded-lg px-3">
             <div className="text-[#8696a0] mr-4"><Icons.Chat /></div>
             <input 
               type="text" 
               placeholder="Pesquisar ou começar uma nova conversa" 
               className="w-full bg-transparent border-none py-1.5 text-sm text-[#d1d7db] outline-none placeholder-[#8696a0]"
             />
          </div>
        </div>

        <div className="flex-1 overflow-y-auto">
          {conversations.length === 0 ? (
            <div className="p-10 text-center text-[#8696a0] text-sm font-medium">
              Carregando contatos...
            </div>
          ) : (
            conversations.map((chat) => (
              <button 
                key={chat.id}
                onClick={() => setSelectedChat(chat)}
                className={`w-full h-[72px] flex items-center px-3 hover:bg-[#2a3942] transition-colors relative ${
                  selectedChat?.id === chat.id ? 'bg-[#2a3942]' : ''
                }`}
              >
                <div className="w-12 h-12 rounded-full overflow-hidden shrink-0 bg-[#4f5e67] mr-3">
                   {chat.participants[0].avatar ? (
                     <img src={chat.participants[0].avatar} className="w-full h-full object-cover" alt="" />
                   ) : (
                     <div className="w-full h-full flex items-center justify-center text-white/50"><Icons.User /></div>
                   )}
                </div>
                <div className="flex-1 border-b border-[#222d34] h-full flex flex-col justify-center min-w-0 pr-2">
                   <div className="flex justify-between items-center mb-1">
                      <span className="text-[#e9edef] text-[17px] font-normal truncate">{chat.participants[0].name}</span>
                      <span className="text-[12px] text-[#8696a0]">
                        {chat.messages.length > 0 ? new Date(chat.messages[chat.messages.length-1].timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}) : ''}
                      </span>
                   </div>
                   <div className="flex items-center gap-1 min-w-0">
                      {chat.messages.length > 0 && chat.messages[chat.messages.length-1].senderId === currentUser.id && (
                        renderCheckmarks(chat.messages[chat.messages.length-1].status)
                      )}
                      <p className="text-[#8696a0] text-sm truncate flex-1">
                        {DatabaseService.isUserTyping(chat.id, chat.participants[0].id) 
                          ? <span className="text-[#00a884] font-medium">digitando...</span>
                          : (chat.messages.length > 0 ? chat.messages[chat.messages.length-1].content : 'Inicie uma conversa')
                        }
                      </p>
                   </div>
                </div>
              </button>
            ))
          )}
        </div>
      </div>

      {/* Janela de Chat (Direita) */}
      <div className="flex-1 flex flex-col relative bg-[#0b141a]">
        {selectedChat ? (
          <>
            <header className="h-[59px] bg-[#202c33] border-l border-white/5 flex items-center px-4 py-2 justify-between shrink-0 z-20">
              <div className="flex items-center gap-3 cursor-pointer">
                 <div className="w-10 h-10 rounded-full overflow-hidden bg-[#4f5e67]">
                   {selectedChat.participants[0].avatar ? (
                     <img src={selectedChat.participants[0].avatar} className="w-full h-full object-cover" alt="" />
                   ) : (
                     <div className="w-full h-full flex items-center justify-center text-white/50"><Icons.User /></div>
                   )}
                 </div>
                 <div className="min-w-0">
                    <h4 className="text-[#e9edef] font-medium text-[16px] truncate leading-tight">{selectedChat.participants[0].name}</h4>
                    <p className="text-[13px] text-[#8696a0] leading-tight">
                      {isOtherTyping ? <span className="text-[#00a884]">digitando...</span> : 'online'}
                    </p>
                 </div>
              </div>
              <div className="flex gap-6 text-[#aebac1]">
                 <svg xmlns="http://www.w3.org/2000/svg" className="w-5 h-5 cursor-pointer" fill="currentColor" viewBox="0 0 24 24"><path d="M15.5 14h-.79l-.28-.27A6.471 6.471 0 0 0 16 9.5 6.5 6.5 0 1 0 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/></svg>
                 <svg xmlns="http://www.w3.org/2000/svg" className="w-5 h-5 cursor-pointer" fill="currentColor" viewBox="0 0 24 24"><path d="M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z"/></svg>
              </div>
            </header>

            <div 
              ref={scrollRef}
              className="flex-1 overflow-y-auto px-[5%] py-4 space-y-2 chat-bg-pattern relative scroll-smooth"
              style={{ backgroundSize: '400px', opacity: 0.9 }}
            >
              {selectedChat.messages.map((msg, i) => {
                const isMe = msg.senderId === currentUser.id;
                return (
                  <div key={msg.id} className={`flex ${isMe ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-[65%] px-3 py-1.5 rounded-lg shadow-sm relative group animate-in ${isMe ? 'bg-[#005c4b] text-[#e9edef] rounded-tr-none' : 'bg-[#202c33] text-[#e9edef] rounded-tl-none'}`}>
                       <p className="text-[14.2px] leading-relaxed break-words whitespace-pre-wrap pr-10">{msg.content}</p>
                       <div className="absolute bottom-1 right-1.5 flex items-center gap-1">
                          <span className="text-[10.5px] text-[#ffffff99] leading-none">
                            {new Date(msg.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                          </span>
                          {isMe && renderCheckmarks(msg.status)}
                       </div>
                       {/* Efeito de cauda do balão */}
                       {isMe ? (
                         <div className="absolute top-0 -right-2 w-2 h-3 bg-[#005c4b]" style={{ clipPath: 'polygon(0 0, 100% 0, 0 100%)' }} />
                       ) : (
                         <div className="absolute top-0 -left-2 w-2 h-3 bg-[#202c33]" style={{ clipPath: 'polygon(0 0, 100% 0, 100% 100%)' }} />
                       )}
                    </div>
                  </div>
                );
              })}
            </div>

            <footer className="h-[62px] bg-[#202c33] flex items-center px-4 py-2 shrink-0 gap-3 z-20">
              <div className="text-[#8696a0] cursor-pointer hover:text-[#d1d7db]"><svg xmlns="http://www.w3.org/2000/svg" className="w-7 h-7" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm5 11h-4v4h-2v-4H7v-2h4V7h2v4h4v2z"/></svg></div>
              <div className="flex-1 relative">
                <input 
                  type="text" 
                  value={messageText}
                  onChange={(e) => handleTyping(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
                  placeholder="Mensagem" 
                  className="w-full bg-[#2a3942] rounded-lg px-4 py-2.5 text-[#d1d7db] outline-none text-sm placeholder-[#8696a0]"
                />
              </div>
              <button 
                onClick={handleSendMessage}
                disabled={!messageText.trim()}
                className={`transition-all ${messageText.trim() ? 'text-[#00a884]' : 'text-[#8696a0]'}`}
              >
                {messageText.trim() ? <Icons.Send /> : <Icons.Voice />}
              </button>
            </footer>
          </>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center text-center p-12 bg-[#222e35] border-l border-white/5">
             <div className="w-24 h-24 mb-6 text-[#00a884] opacity-20">
                <Icons.Rocket />
             </div>
             <h3 className="text-[#e9edef] text-[32px] font-light mb-4">Zap Conect AI</h3>
             <p className="text-[#8696a0] max-w-md text-sm leading-relaxed mb-8">
               Envie e receba mensagens sem precisar manter seu celular conectado. <br/>
               Use o Zap Conect em até 4 dispositivos vinculados e 1 celular ao mesmo tempo.
             </p>
             <div className="flex items-center gap-1.5 text-[#8696a0] text-[13px] absolute bottom-12">
                <svg xmlns="http://www.w3.org/2000/svg" className="w-3 h-3" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm.5-13H11v6l5.25 3.15.75-1.23-4.5-2.67z"/></svg>
                Protegido com IA Gemini
             </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ChatView;
