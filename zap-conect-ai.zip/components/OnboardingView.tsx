
import React, { useState } from 'react';
import emailjs from 'https://esm.sh/@emailjs/browser';
import { EMAILJS_SERVICE_ID, EMAILJS_TEMPLATE_ID, EMAILJS_PUBLIC_KEY, Icons } from '../constants';

interface OnboardingProps {
  userEmail: string;
  userName: string;
  onNumberSelected: (phone: string, code: string) => void;
}

const OnboardingView: React.FC<OnboardingProps> = ({ userEmail, userName, onNumberSelected }) => {
  const [choice, setChoice] = useState<'virtual' | 'chip' | null>(null);
  const [ddi, setDdi] = useState('+55');
  const [ddd, setDdd] = useState('11');
  const [chipPhone, setChipPhone] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleConfirm = async () => {
    setIsLoading(true);
    const code = Math.floor(100000 + Math.random() * 900000).toString();
    const phone = choice === 'virtual' 
      ? `${ddi} (${ddd}) 9${Math.floor(10000000 + Math.random() * 90000000)}` 
      : chipPhone;

    try {
      await emailjs.send(EMAILJS_SERVICE_ID, EMAILJS_TEMPLATE_ID, {
        to_email: userEmail,
        name: userName,
        user_name: userName,
        code: code,
        verification_code: code,
        message: code,
      }, EMAILJS_PUBLIC_KEY);
      onNumberSelected(phone, code);
    } catch (error) {
      alert('Erro ao enviar código. Verifique as configurações.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#111b21] flex items-center justify-center p-6 text-[#e9edef]">
      <div className="w-full max-w-2xl space-y-8 animate-in fade-in zoom-in-95">
        <div className="text-center space-y-4">
          <div className="w-20 h-20 bg-[#00a884]/10 rounded-2xl flex items-center justify-center mx-auto p-4 text-[#00a884] border border-[#00a884]/20">
            <Icons.Rocket />
          </div>
          <h2 className="text-3xl font-bold tracking-tight">Configure sua conta</h2>
          <p className="text-[#8696a0] font-medium">Escolha como você quer se conectar ao sistema</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <button 
            onClick={() => setChoice('virtual')}
            className={`p-8 rounded-2xl border transition-all text-left bg-[#222e35] ${
              choice === 'virtual' ? 'border-[#00a884] ring-1 ring-[#00a884]/50' : 'border-white/5 hover:border-white/20'
            }`}
          >
            <div className={`w-12 h-12 rounded-xl flex items-center justify-center mb-4 transition-all ${
              choice === 'virtual' ? 'bg-[#00a884] text-[#111b21]' : 'bg-[#2a3942] text-[#8696a0]'
            }`}>
              <svg xmlns="http://www.w3.org/2000/svg" className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" /></svg>
            </div>
            <h3 className="font-bold text-lg mb-2">Número Virtual</h3>
            <p className="text-xs text-[#8696a0] leading-relaxed">Gere uma identidade digital em segundos.</p>
          </button>

          <button 
            onClick={() => setChoice('chip')}
            className={`p-8 rounded-2xl border transition-all text-left bg-[#222e35] ${
              choice === 'chip' ? 'border-[#00a884] ring-1 ring-[#00a884]/50' : 'border-white/5 hover:border-white/20'
            }`}
          >
            <div className={`w-12 h-12 rounded-xl flex items-center justify-center mb-4 transition-all ${
              choice === 'chip' ? 'bg-[#00a884] text-[#111b21]' : 'bg-[#2a3942] text-[#8696a0]'
            }`}>
              <svg xmlns="http://www.w3.org/2000/svg" className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z" /></svg>
            </div>
            <h3 className="font-bold text-lg mb-2">Seu Número</h3>
            <p className="text-xs text-[#8696a0] leading-relaxed">Utilize um número que você já possui.</p>
          </button>
        </div>

        <div className="flex justify-center mt-10">
          <button 
            disabled={!choice || isLoading}
            onClick={handleConfirm}
            className="px-16 py-4 bg-[#00a884] text-[#111b21] font-bold rounded-full hover:bg-[#06cf9c] transition-all disabled:opacity-30 uppercase tracking-widest active:scale-95 shadow-xl shadow-[#00a884]/10"
          >
            {isLoading ? 'ENVIANDO...' : 'CONFIRMAR'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default OnboardingView;
