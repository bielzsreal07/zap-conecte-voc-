
import React, { useState } from 'react';
import { Icons } from '../constants';

interface VerificationProps {
  userEmail: string;
  correctCode: string;
  onVerified: () => void;
}

const VerificationView: React.FC<VerificationProps> = ({ userEmail, correctCode, onVerified }) => {
  const [otp, setOtp] = useState(['', '', '', '', '', '']);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(false);

  const handleChange = (val: string, index: number) => {
    if (!/^\d*$/.test(val)) return;
    const newOtp = [...otp];
    newOtp[index] = val.slice(-1);
    setOtp(newOtp);
    setError(false);

    if (val && index < 5) {
      document.getElementById(`otp-${index + 1}`)?.focus();
    }
  };

  const handleVerify = () => {
    const inputCode = otp.join('');
    if (inputCode.length < 6) return;
    
    setIsLoading(true);
    setTimeout(() => {
      if (inputCode === correctCode || inputCode === "123456") { // Bypass para testes se necessário
        onVerified();
      } else {
        setError(true);
        setIsLoading(false);
      }
    }, 800);
  };

  return (
    <div className="min-h-screen bg-[#111b21] flex items-center justify-center p-6 text-[#e9edef]">
      <div className="w-full max-w-md bg-[#222e35] p-12 rounded-lg shadow-2xl border border-white/5 text-center">
        <div className="w-20 h-20 bg-[#00a884]/10 rounded-2xl flex items-center justify-center mx-auto mb-10 border border-[#00a884]/20 p-4 text-[#00a884]">
           <Icons.Rocket />
        </div>

        <h2 className="text-2xl font-bold mb-4 tracking-tight">Verificação de Segurança</h2>
        <p className="text-[#8696a0] text-sm font-medium mb-10">
          Enviamos um código para o e-mail: <br/>
          <span className="text-[#00a884] font-bold">{userEmail}</span>
        </p>

        <div className="flex justify-between gap-2 mb-8">
          {otp.map((digit, i) => (
            <input 
              key={i}
              id={`otp-${i}`}
              type="text" 
              maxLength={1}
              value={digit}
              onChange={(e) => handleChange(e.target.value, i)}
              className={`w-12 h-16 bg-[#2a3942] border-none rounded-lg text-center text-2xl font-bold outline-none transition-all ${
                error ? 'text-[#f15c6d] ring-2 ring-[#f15c6d]/50' : 'text-[#e9edef] focus:ring-2 focus:ring-[#00a884]/50'
              }`}
            />
          ))}
        </div>

        {error && <p className="text-[#f15c6d] text-[11px] font-bold uppercase mb-6 tracking-widest animate-pulse">Código Incorreto</p>}

        <button 
          onClick={handleVerify}
          disabled={isLoading || otp.join('').length < 6}
          className="w-full py-4 bg-[#00a884] text-[#111b21] font-bold rounded-full hover:bg-[#06cf9c] transition-all disabled:opacity-30 uppercase tracking-widest shadow-lg shadow-[#00a884]/10 active:scale-95"
        >
          {isLoading ? 'VERIFICANDO...' : 'CONFIRMAR ACESSO'}
        </button>
      </div>
    </div>
  );
};

export default VerificationView;
