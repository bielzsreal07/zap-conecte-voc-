
import { User, ChatMessage, Conversation } from '../types';

const DB_KEYS = {
  USERS: 'zap_db_users',
  MESSAGES: 'zap_db_messages',
  CURRENT_USER: 'zap_db_session',
  TYPING: 'zap_db_typing'
};

export class DatabaseService {
  private static getRaw(key: string) {
    try {
      const data = localStorage.getItem(key);
      return data ? JSON.parse(data) : null;
    } catch (e) {
      return null;
    }
  }

  private static setRaw(key: string, data: any) {
    try {
      localStorage.setItem(key, JSON.stringify(data));
    } catch (e) {
      console.error("Erro ao salvar no localStorage", e);
    }
  }

  static saveUser(user: User) {
    const users = this.getRaw(DB_KEYS.USERS) || [];
    const index = users.findIndex((u: any) => u.email === user.email);
    
    if (index >= 0) {
      // Mescla os dados para não perder a senha ou telefone
      users[index] = { ...users[index], ...user };
    } else {
      users.push(user);
    }
    this.setRaw(DB_KEYS.USERS, users);
  }

  static getUserByEmail(email: string): User | null {
    const users = this.getRaw(DB_KEYS.USERS) || [];
    return users.find((u: any) => u.email === email) || null;
  }

  static getAllUsers(): User[] {
    return this.getRaw(DB_KEYS.USERS) || [];
  }

  static setSession(user: User) {
    this.setRaw(DB_KEYS.CURRENT_USER, user);
  }

  static getSession(): User | null {
    return this.getRaw(DB_KEYS.CURRENT_USER);
  }

  static clearSession() {
    localStorage.removeItem(DB_KEYS.CURRENT_USER);
  }

  static saveMessage(msg: ChatMessage) {
    const messages = this.getRaw(DB_KEYS.MESSAGES) || [];
    messages.push(msg);
    this.setRaw(DB_KEYS.MESSAGES, messages);
  }

  static getMessagesForChat(chatId: string): ChatMessage[] {
    const messages = this.getRaw(DB_KEYS.MESSAGES) || [];
    return messages.filter((m: ChatMessage) => m.chatId === chatId);
  }

  static markMessagesAsDelivered(chatId: string, recipientId: string) {
    const messages = this.getRaw(DB_KEYS.MESSAGES) || [];
    let updated = false;
    const newMessages = messages.map((m: ChatMessage) => {
      if (m.chatId === chatId && m.senderId !== recipientId && m.status === 'sent') {
        updated = true;
        return { ...m, status: 'delivered' as const };
      }
      return m;
    });
    if (updated) this.setRaw(DB_KEYS.MESSAGES, newMessages);
  }

  static markMessagesAsRead(chatId: string, readerId: string) {
    const messages = this.getRaw(DB_KEYS.MESSAGES) || [];
    let updated = false;
    const newMessages = messages.map((m: ChatMessage) => {
      if (m.chatId === chatId && m.senderId !== readerId && m.status !== 'read') {
        updated = true;
        return { ...m, status: 'read' as const };
      }
      return m;
    });
    if (updated) this.setRaw(DB_KEYS.MESSAGES, newMessages);
  }

  static setTypingStatus(chatId: string, userId: string, isTyping: boolean) {
    const typingMap = this.getRaw(DB_KEYS.TYPING) || {};
    if (!typingMap[chatId]) typingMap[chatId] = {};
    if (isTyping) typingMap[chatId][userId] = Date.now();
    else delete typingMap[chatId][userId];
    this.setRaw(DB_KEYS.TYPING, typingMap);
  }

  static isUserTyping(chatId: string, userId: string): boolean {
    const typingMap = this.getRaw(DB_KEYS.TYPING) || {};
    const timestamp = typingMap[chatId]?.[userId];
    if (!timestamp) return false;
    if (Date.now() - timestamp > 4000) return false;
    return true;
  }

  static async sendBulkMessage(senderId: string, content: string, onProgress?: (current: number, total: number) => void) {
    const users = this.getAllUsers().filter(u => u.id !== senderId);
    const total = users.length;
    for (let i = 0; i < total; i++) {
      const targetUser = users[i];
      const chatId = [senderId, targetUser.id].sort().join('_');
      const newMessage: ChatMessage = {
        id: `bulk-${Date.now()}-${targetUser.id}`,
        chatId: chatId,
        senderId: senderId,
        content: content,
        type: 'text',
        status: 'sent',
        timestamp: Date.now()
      };
      this.saveMessage(newMessage);
      if (onProgress) onProgress(i + 1, total);
      await new Promise(r => setTimeout(r, 100));
    }
  }

  static initSeed() {
    if (!this.getRaw(DB_KEYS.USERS)) this.setRaw(DB_KEYS.USERS, []);
  }
}
